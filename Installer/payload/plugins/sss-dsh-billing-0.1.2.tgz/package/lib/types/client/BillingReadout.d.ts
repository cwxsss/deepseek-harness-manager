import type { ConversationSnapshot, UseProjection } from '@deepseek-ai/dsh-client-runtime/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { IApiClient } from '@deepseek-ai/dsh-client-connection/client';
export interface BillingReadoutProps {
    useSession: SnapshotSelectorHook<ConversationSnapshot>;
    useProjection: UseProjection;
    t: (key: 'billing.costThis' | 'billing.costTotal' | 'billing.balance' | 'billing.unavailable', params?: Record<string, string>) => string;
    api?: IApiClient;
}
export declare const BillingReadout: import("react").MemoExoticComponent<({ useSession, useProjection, t, api }: BillingReadoutProps) => import("react").JSX.Element | null>;
//# sourceMappingURL=BillingReadout.d.ts.map