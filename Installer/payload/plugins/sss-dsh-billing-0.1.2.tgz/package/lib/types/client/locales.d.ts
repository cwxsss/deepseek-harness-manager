/** Dictionary namespace owned by the billing plugin. */
export declare const NS = "sssDshBilling";
/** Simplified Chinese dictionary and key source of truth. */
export declare const zh: {
    'billing.costThis': string;
    'billing.costTotal': string;
    'billing.balance': string;
    'billing.unavailable': string;
};
/** Billing dictionary key union. */
export type BillingLocaleKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    'billing.costThis': string;
    'billing.costTotal': string;
    'billing.balance': string;
    'billing.unavailable': string;
};
//# sourceMappingURL=locales.d.ts.map