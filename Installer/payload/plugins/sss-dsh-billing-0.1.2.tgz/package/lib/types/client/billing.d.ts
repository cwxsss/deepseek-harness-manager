/** DeepSeek token prices in CNY per million tokens. */
export interface DeepSeekPriceTier {
    input: number;
    cacheRead: number;
    output: number;
}
/** Price tiers used for cost estimates in the conversation header. */
export declare const DEEPSEEK_PRICES: Record<string, DeepSeekPriceTier>;
/** Fallback tier for unknown non-reasoning models. */
export declare const DEEPSEEK_DEFAULT_TIER: DeepSeekPriceTier;
/**
 * Resolve the price tier for a request model.
 * @param model - Provider model id, when recorded.
 * @returns The matching or fallback tier.
 */
export declare function deepSeekTierFor(model: string | undefined): DeepSeekPriceTier;
/** Token categories billed by the readout. */
export interface BillingTokenUsage {
    uncachedInputTokens: number;
    cacheReadTokens: number;
    cacheWriteTokens: number;
    outputTokens: number;
}
/** Conversation-node fields required for task usage aggregation. */
export interface BillingNodeLike {
    kind: string;
    usage?: unknown;
}
/**
 * Normalize a model usage payload into billing token categories.
 * @param usage - Untrusted node usage value.
 * @returns Normalized non-empty usage, or undefined.
 */
export declare function normalizeNodeUsage(usage: unknown): BillingTokenUsage | undefined;
/**
 * Sum assistant usage after the latest user or steering node.
 * @param nodes - Settled conversation nodes in display order.
 * @returns Aggregated task usage, or undefined when no assistant reported usage.
 */
export declare function lastTaskUsage(nodes: readonly BillingNodeLike[]): BillingTokenUsage | undefined;
/**
 * Compare all billed token categories.
 * @param a - First usage value.
 * @param b - Second usage value.
 * @returns Whether every category matches.
 */
export declare function sameTokenUsage(a: BillingTokenUsage, b: BillingTokenUsage): boolean;
/**
 * Calculate an estimated CNY cost.
 * @param u - Token usage to price.
 * @param tier - CNY price tier.
 * @returns Estimated cost in CNY.
 */
export declare function deepSeekCost(u: BillingTokenUsage, tier: DeepSeekPriceTier): number;
/**
 * Format a cost without insignificant trailing zeroes.
 * @param cost - Non-negative currency value.
 * @returns Compact decimal text.
 */
export declare function formatCost(cost: number): string;
/**
 * Render a known currency symbol or a currency-code prefix.
 * @param currency - ISO-style currency code.
 * @returns Prefix for a formatted amount.
 */
export declare function currencySymbol(currency: string): string;
//# sourceMappingURL=billing.d.ts.map