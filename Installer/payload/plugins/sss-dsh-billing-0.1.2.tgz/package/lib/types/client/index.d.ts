import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type BillingLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        sssDshBilling: BillingLocaleKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map