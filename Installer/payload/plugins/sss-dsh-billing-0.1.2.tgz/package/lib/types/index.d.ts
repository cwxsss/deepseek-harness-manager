/** External billing plugin; browser behavior is provided by `./client`. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map