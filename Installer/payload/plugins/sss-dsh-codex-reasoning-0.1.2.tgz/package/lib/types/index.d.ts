/** External Codex reasoning-effort capability for a configured pi-ai route. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "sss-dsh-codex-reasoning";
export declare const inject: string[];
/** Configuration selecting the pi-ai provider and Codex model-id prefix. */
export interface Config {
    /** Exact pi-ai provider route to decorate. */
    provider: string;
    /** Model-id prefix identifying Codex routes on that provider. */
    modelPrefix: string;
}
export declare const Config: z<Config>;
/** Install the managed capability and restore the pre-plugin fields on disposal. */
export declare function apply(ctx: Context, config: Config): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map