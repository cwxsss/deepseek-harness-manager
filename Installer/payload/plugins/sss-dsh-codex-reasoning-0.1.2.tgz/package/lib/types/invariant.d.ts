/** Package-owned invariant companion. @module sss-dsh-codex-reasoning/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "sss-dsh-codex-reasoning-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map