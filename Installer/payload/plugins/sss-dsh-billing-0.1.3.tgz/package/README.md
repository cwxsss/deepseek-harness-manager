# SSS dsh Billing

English | [中文](README.zh.md)

Optional Web client plugin that registers a `conversation.session.header.utilities` readout. It estimates the latest task and complete session cost from durable token-usage projections, and requests the current DeepSeek account balance when the Host exposes the `billing.balance` RPC so the API key never enters the browser. When that RPC is unavailable, local cost rendering remains active instead of crashing the header utility slot.

Install the packed plugin into a Web profile with `dsh plugin --profile web add <path-to-sss-dsh-billing.tgz>`. The package declares a bundle patch, so successful installation adds its Loader row; removal through `dsh plugin --profile web remove sss-dsh-billing` removes that row. The Web Plugins settings tab can search for **SSS dsh Billing** and change its state in the live Loader tree.

The readout uses CNY-per-million-token tiers keyed by the request model. Unknown non-reasoning models use the flash tier, while unknown model names containing `reasoner` use the reasoner tier. The balance button refreshes the Host query; missing credentials or an unavailable balance endpoint render a localized unavailable state without exposing the credential.

## Model Experience

None, as this package only renders browser billing state and does not change model context or provider requests.

#### KV Cache effect

None. The package reads existing cache-token counters but does not change cache usage.

## Known Limitations and Deferred Work

- Loader enablement changes are live-process state; restarting Harness recomposes the profile and restores the state declared by its patch layers.
- Cost values are estimates based on the package's model-price table; provider-side discounts or later price changes require a package update.
