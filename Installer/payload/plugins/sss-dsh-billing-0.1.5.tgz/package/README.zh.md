# SSS dsh Billing

[English](README.md) | 中文

这是一个可选的 Web 客户端插件，会注册 `conversation.session.header.utilities` 读数。它根据持久化的 token 用量投影估算本次任务和本次项目费用，并由 Host 使用凭据服务查询当前 DeepSeek 账户余额，因此 API 密钥不会进入浏览器。

使用 `dsh plugin --profile web add <path-to-sss-dsh-billing.tgz>` 将打包插件安装到 Web profile。该包声明了 bundle patch，因此安装成功后会添加对应 Loader 条目；使用 `dsh plugin --profile web remove sss-dsh-billing` 删除依赖时也会移除该条目。Web 的“插件”设置页可以搜索 **SSS dsh Billing**，并更改它在当前 Loader 进程中的状态。

读数只在当前会话使用 DeepSeek 模型时显示。模型选择优先读取已记录的请求模型，并回退到当前会话模型选择器；费用按每条请求的模型、时间和北京时间峰谷时段选择官方人民币价格。单击余额按钮会重新请求 Host；缺少凭据或余额接口不可用时只显示本地化的不可用状态，不会暴露凭据。

## 模型体验

无，因为该包只渲染浏览器计费状态，不会改变模型上下文或提供方请求。

#### KV 缓存影响

无。该包读取现有缓存 token 计数，但不改变缓存用量。

## 已知限制和延期工作

- Loader 启停只影响当前进程；Harness 重启后会重新组合 profile，并恢复 patch 层声明的状态。
- 费用是根据包内模型价格表计算的估算值；服务端折扣或后续价格调整需要更新该包。
