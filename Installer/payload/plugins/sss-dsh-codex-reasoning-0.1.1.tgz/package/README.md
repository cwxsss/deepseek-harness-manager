# SSS Codex Reasoning

English | [中文](README.zh.md)

External Host plugin that adds exactly **Low**, **Medium**, and **High** reasoning choices to Codex models on a configured `llm-pi-ai` provider route. Its default bundle patch targets provider `omniroute` and model ids beginning with `cx/`; deployments can change those two values in a later profile patch.

Install the packed plugin with `dsh plugin --profile web add <path-to-sss-dsh-codex-reasoning.tgz>`. While mounted, the plugin manages each matching model's `reasoningEfforts` map, selects Medium as the deployment default, and enables OpenAI-style `reasoning_effort` dispatch for the route. Disabling or removing the plugin restores the fields that existed before it mounted; an exact managed value left by a force-terminated process is recognized as plugin state rather than adopted as a new baseline. The capability is therefore neither a source-tree nor permanent settings customization.

## Model Experience

Indirectly, through pi-ai request serialization of the selected Low, Medium, or High `reasoning_effort` value.

#### KV Cache effect

None. The plugin changes request reasoning metadata only.

## Known Limitations and Deferred Work

- The default match is intentionally narrow (`omniroute` plus `cx/`). A differently named provider or model prefix needs a profile patch for this plugin's Loader row.
- The target route must use the `openai-completions` protocol because the managed compatibility fields belong to that protocol.
