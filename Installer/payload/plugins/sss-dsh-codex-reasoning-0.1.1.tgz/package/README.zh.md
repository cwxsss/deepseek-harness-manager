# SSS Codex Reasoning

[English](README.md) | 中文

这是一个外挂 Host 插件，会为指定 `llm-pi-ai` 提供方路由下的 Codex 模型增加且只增加**低**、**中**、**高**三个推理等级。默认 bundle patch 面向 `omniroute` 提供方以及 id 以 `cx/` 开头的模型；其他部署可以在更后的 profile patch 中改写这两个值。

使用 `dsh plugin --profile web add <path-to-sss-dsh-codex-reasoning.tgz>` 安装打包插件。插件挂载期间会管理匹配模型的 `reasoningEfforts` 映射，把中档设为部署默认值，并为该路由启用 OpenAI 风格的 `reasoning_effort` 分派。停用或删除插件时会恢复它挂载前存在的字段；进程被强制终止后遗留的精确受管值会被识别为插件状态，而不会成为新的基线。因此这项能力既不是源码内置修改，也不是永久设置定制。

## 模型体验

间接影响，通过 pi-ai 将选中的低、中或高档位序列化为 `reasoning_effort` 请求值。

#### KV 缓存影响

无。插件只改变请求的推理元数据。

## 已知限制和延期工作

- 默认匹配刻意限定为 `omniroute` 与 `cx/`。使用其他提供方名称或模型前缀时，需要在 profile patch 中改写本插件的 Loader 条目配置。
- 目标路由必须使用 `openai-completions` 协议，因为插件管理的兼容字段只属于该协议。
